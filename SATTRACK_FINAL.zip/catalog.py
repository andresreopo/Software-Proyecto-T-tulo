"""Catálogo local CelesTrak/SatNOGS con actualización no bloqueante."""

from __future__ import annotations

import datetime as dt
import json
import threading
import time
from zoneinfo import ZoneInfo
from pathlib import Path

import requests
from skyfield.api import EarthSatellite, load, wgs84

from orbit import find_passes


CHILE = ZoneInfo("America/Santiago")
BAND_RANGES = {"l": (1600.0, 2000.0), "s": (2000.0, 4000.0)}   # MHz
WINDOW_STEP_MIN = 2   # paso de muestreo para el filtro por franja horaria
DATA = Path(__file__).resolve().parent / "data"
CELESTRAK = "https://celestrak.org/NORAD/elements/gp.php"
SATNOGS = "https://db.satnogs.org/api/transmitters/"
HEADERS = {"User-Agent": "SatTrackMaiaSim/1.0 (academic prototype)"}


def _read(name, default):
    try:
        return json.loads((DATA / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(name, data):
    DATA.mkdir(parents=True, exist_ok=True)
    path = DATA / name
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)


def _age_hours(meta):
    try:
        stamp = meta.get("fetched_at") or meta.get("saved_at")
        moment = dt.datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        return (dt.datetime.now(dt.timezone.utc) - moment).total_seconds() / 3600
    except (AttributeError, TypeError, ValueError):
        return None


class CatalogStore:
    def __init__(self):
        self.lock = threading.RLock()
        self.records = _read("active.json", [])
        self.orbit_meta = _read("active.meta.json", {})
        self.transmitters = _read("transmitters.json", [])
        self.tx_meta = _read("transmitters.meta.json", {})
        self.by_id = {}
        self.tx_by_id = {}
        self.updating = False
        self.updating_sources = set()           # "tle" y/o "tx" en curso
        self.source_errors = {}                 # último error por fuente
        self.last_error = None
        self._reindex()

    def _reindex(self):
        self._azimuth_results = None
        self.by_id = {
            int(r["NORAD_CAT_ID"]): r for r in self.records
            if isinstance(r, dict) and r.get("NORAD_CAT_ID") and r.get("EPOCH")
        }
        grouped = {}
        for tx in self.transmitters:
            try:
                norad = int(tx.get("norad_cat_id") or 0)
                frequency = tx.get("downlink_low") or tx.get("downlink_high")
                if tx.get("status") != "active" or not norad or frequency is None:
                    continue
                grouped.setdefault(norad, []).append(tx)
            except (TypeError, ValueError, AttributeError):
                continue
        self.tx_by_id = grouped

    def status(self):
        with self.lock:
            orbital_age = _age_hours(self.orbit_meta)
            tx_age = _age_hours(self.tx_meta)
            return {
                "catalog_count": len(self.by_id),
                "transmitter_count": len(self.transmitters),
                "celestrak": {**self.orbit_meta, "age_hours": round(orbital_age, 1) if orbital_age is not None else None,
                              "stale": orbital_age is None or orbital_age > 24},
                "satnogs": {**self.tx_meta, "age_hours": round(tx_age, 1) if tx_age is not None else None,
                            "stale": tx_age is None or tx_age > 24},
                "updating": self.updating,
                "updating_sources": sorted(self.updating_sources),
                "last_error": self.last_error,
            }

    def record(self, norad):
        with self.lock:
            return self.by_id.get(int(norad))

    def transmitters_for(self, norad, band_only=False, ranges=None):
        """`band_only` = solo bajadas L+S (1600–4000 MHz), las que admite la sesión; `ranges` = lista de (min, max) MHz."""
        if ranges is None and band_only:
            ranges = [BAND_RANGES["l"], BAND_RANGES["s"]]
        with self.lock:
            records = list(self.tx_by_id.get(int(norad), []))
        result = []
        for tx in records:
            low = tx.get("downlink_low")
            high = tx.get("downlink_high")
            try:
                freq = float(low if low is not None else high) / 1e6
                upper = float(high if high is not None else low) / 1e6
            except (TypeError, ValueError):
                continue
            if ranges is not None and not any(lo <= freq <= hi for lo, hi in ranges):
                continue
            result.append({
                "uuid": tx.get("uuid"),
                "frequency_mhz": round(freq, 6),
                "high_mhz": round(upper, 6),
                "mode": tx.get("mode") or "Desconocido",
                "description": tx.get("description") or "Bajada catalogada",
                "service": tx.get("service"),
                "unconfirmed": bool(tx.get("unconfirmed")),
                "updated": tx.get("updated"),
            })
        return sorted(result, key=lambda item: item["frequency_mhz"])

    def search(self, query, band, visible_only, observer, page, page_size, hours=None, azimuth=None):
        """Busca en el catálogo, con filtros opcionales de pase durante las próximas 24 h.

        `hours` se expresa en minutos del día en Chile. `azimuth` es un arco horario en grados.
        """
        query = str(query or "").strip().casefold()[:80]
        begin = (page - 1) * page_size
        cache_key = (query, band, tuple(observer.items()), hours, azimuth) if azimuth and not visible_only else None
        with self.lock:
            cache = self._azimuth_results
            if cache_key and cache and cache[0] == cache_key and time.monotonic() < cache[1]:
                _, _, items, computed_at = cache
                return {"items": items[begin:begin + page_size], "total": len(items),
                        "page": page, "page_size": page_size, "computed_at": computed_at}
            record_index = self.by_id
            records = list(record_index.values())
            tx_ids = set(self.tx_by_id)
        ranges = None if band == "all" else [BAND_RANGES[b] for b in band if b in BAND_RANGES]   # "s", "l", "sl" o "all"
        if ranges:
            records = [r for r in records if int(r["NORAD_CAT_ID"]) in tx_ids
                       and self.transmitters_for(int(r["NORAD_CAT_ID"]), ranges=ranges)]
        if query:
            records = [r for r in records if query in str(r.get("OBJECT_NAME", "")).casefold()
                       or query in str(r["NORAD_CAT_ID"])]
        ts = load.timescale()
        moment = ts.now()
        now = moment.utc_datetime()
        station = wgs84.latlon(observer["lat"], observer["lon"], elevation_m=observer["alt_m"])
        window = None
        if hours is not None and azimuth is None:
            start = dt.datetime.now(dt.timezone.utc).replace(second=0, microsecond=0)
            moments = [start + dt.timedelta(minutes=WINDOW_STEP_MIN * k) for k in range(1440 // WINDOW_STEP_MIN + 1)]
            keep = []
            for k, m in enumerate(moments):
                local = m.astimezone(CHILE)
                if hours[0] <= local.hour * 60 + local.minute < hours[1]:
                    keep.append(k)
            if not keep:
                return {"items": [], "total": 0, "page": page, "page_size": page_size,
                        "computed_at": moment.utc_datetime().isoformat()}
            window = ts.from_datetimes([moments[k] for k in keep])
        items = []
        for record in records:
            try:
                sat = EarthSatellite.from_omm(ts, record)
                elevation, bearing, _ = (sat - station).at(moment).altaz()
                el = float(elevation.degrees)
                if visible_only and el < observer["min_el"]:
                    continue
                window_max = None
                if azimuth is not None:
                    matches = find_passes(record, observer, start=now, days=1,
                                          limit=1 if hours is None or visible_only else None,
                                          azimuth=azimuth, hours=hours)
                    if not matches or (visible_only and not matches[0]["in_progress"]):
                        continue
                    if hours is not None:
                        window_max = max(p["max_el_deg"] for p in matches)
                elif window is not None:
                    w_el = (sat - station).at(window).altaz()[0].degrees
                    window_max = float(w_el.max())
                    if window_max < observer["min_el"]:
                        continue
                tx = self.transmitters_for(int(record["NORAD_CAT_ID"]), band_only=ranges is None, ranges=ranges)
                items.append({
                    "norad_id": int(record["NORAD_CAT_ID"]),
                    "name": record.get("OBJECT_NAME") or f"NORAD {record['NORAD_CAT_ID']}",
                    "elevation_deg": round(el, 1),
                    "azimuth_deg": round(float(bearing.degrees), 1),
                    "visible_now": el >= observer["min_el"],
                    "frequencies_mhz": sorted({x["frequency_mhz"] for x in tx}),
                    "epoch_utc": record.get("EPOCH"),
                    "window_max_el_deg": None if window_max is None else round(window_max, 1),
                })
            except (ValueError, TypeError, KeyError, ArithmeticError):
                continue
        items.sort(key=lambda x: (-x["elevation_deg"], x["name"]) if visible_only
                   else (x["name"].casefold(), x["norad_id"]))
        computed_at = now.isoformat()
        if cache_key:
            with self.lock:
                if self.by_id is record_index:
                    # Reutiliza la misma lista al paginar el cálculo orbital.
                    self._azimuth_results = (cache_key, time.monotonic() + 60, items, computed_at)
        return {"items": items[begin:begin + page_size], "total": len(items),
                "page": page, "page_size": page_size, "computed_at": computed_at}

    def refresh_async(self, sources=("tle", "tx")):
        """Actualiza en segundo plano las fuentes pedidas: "tle" (CelesTrak) y/o "tx" (transmisores SatNOGS),
        cada una por separado. Devuelve las que arrancaron (las que ya se estaban actualizando se omiten)."""
        started = []
        for source in sources:
            if source not in ("tle", "tx"):
                raise ValueError("Fuente desconocida: usa tle o tx.")
            with self.lock:
                if source in self.updating_sources:
                    continue
                self.updating_sources.add(source)
                self.updating = True
                self.source_errors.pop(source, None)
                self.last_error = "; ".join(self.source_errors.values()) or None
            target = self._refresh_tle if source == "tle" else self._refresh_tx
            threading.Thread(target=self._run_refresh, args=(source, target), daemon=True,
                             name=f"catalog-refresh-{source}").start()
            started.append(source)
        return started

    def _run_refresh(self, source, target):
        error = None
        try:
            target()
        except (requests.RequestException, ValueError, OSError) as exc:
            error = f"{'CelesTrak' if source == 'tle' else 'SatNOGS'}: {exc}"
        finally:
            with self.lock:
                self.updating_sources.discard(source)
                self.updating = bool(self.updating_sources)
                if error:
                    self.source_errors[source] = error
                self.last_error = "; ".join(self.source_errors.values()) or None

    def _refresh_tle(self):
        response = requests.get(CELESTRAK, params={"GROUP": "ACTIVE", "FORMAT": "JSON"},
                                headers=HEADERS, timeout=(6, 40))
        response.raise_for_status()
        records = response.json()
        if not isinstance(records, list) or len(records) < 1000:
            raise ValueError("Respuesta orbital incompleta")
        valid = [r for r in records if isinstance(r, dict) and r.get("NORAD_CAT_ID")
                 and r.get("EPOCH") and r.get("MEAN_MOTION")]
        meta = {"fetched_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                "source": CELESTRAK + "?GROUP=ACTIVE&FORMAT=JSON", "count": len(valid)}
        _write("active.json", valid)
        _write("active.meta.json", meta)
        with self.lock:
            self.records = valid
            self.orbit_meta = meta
            self._reindex()

    def _refresh_tx(self):
        response = requests.get(SATNOGS, params={"status": "active"},
                                headers=HEADERS, timeout=(6, 35))
        response.raise_for_status()
        records = response.json()
        if not isinstance(records, list) or not records:
            raise ValueError("Respuesta de transmisores vacía")
        meta = {"fetched_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                "source": SATNOGS, "count": len(records)}
        _write("transmitters.json", records)
        _write("transmitters.meta.json", meta)
        with self.lock:
            self.transmitters = records
            self.tx_meta = meta
            self._reindex()


store = CatalogStore()
